<?php ?>

<section class="navigation">
    <img class="logo" src="./img/Logo_Complete.svg" />
    <section class="social-links">
        <a href="#" target="_blank"  title="Twitter">
            <img src="./img/social-twitter.svg" alt="Twitter"/>
        </a>
        <a href="#"  target="_blank" title="Medium">
            <img src="./img/social-medium.svg" alt="Medium"/>
        </a>
    </section>
    <a href="#" class="button-link">work with us</a>
</section>

<?php ?>