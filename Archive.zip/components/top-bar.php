<?php ?>

<section class="top-bar">
    <a href="#" target="_blank">
        <div class="top-bar__decoration">◱ ◰ ◲ ◳</div>
        <div class="top-bar__title">
            <span>read the announcement on Medium</span>
        </div>
        <div class="top-bar__decoration">◰ ◱ ◳ ◲</div>
    </a>
</section>

<?php ?>