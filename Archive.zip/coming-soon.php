<?php ?>

<header>
    <div class="texture-background"></div>
    <img src="src/img/coming-soon.svg" />
</header>

<?php ?>